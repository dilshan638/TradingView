<template>
  <div class="main-layout">
    <div class="col-md-12">
        <slot/>
    </div>
  </div>
</template>

<script>
export default {
  name:'pageContent',
  data(){
      return{

      }
  }
}
</script>
<style>
    @import "../../assets/scss/pagecontent/pagecontent.scss";
</style>