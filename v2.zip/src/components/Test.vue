<template>
  <div>
      <div>Test</div>
  </div>
</template>

<script>
export default {
 name:'Test'
}
</script>

<style>

</style>