<template>
    <login-layout>
        2
    </login-layout>
</template>

<script>
import LoginLayout from '../layout/LoginLayout.vue';

export default {
    name:'check',
    components: {
        LoginLayout
    },
    data(){
        return{

        }
    },
    methods:{
    }
}
</script>

<style>
        @import "../components/SignupForm/signup.scss";
</style>