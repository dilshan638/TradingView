<template>
  <section class="block-four logo-section" data-aos="fade-in">
    <div class="container">
        <div class="row">
          <div class="col-lg-6 text-center">
              <img src="images/ldx-logo.webp" />
          </div>
          <div class="col-lg-6">
              <h2>What is LDXI<br/>
              LDXI, the INPSIRA Digital Currency,<br/>
              providing genuine benefits for <br/>
              INSPIRA members”              
            </h2>
          </div>          
        </div>
    </div>
    <div class="container-fluid">
      <div class="row chart text-center" data-aos="fade-right">
      </div>
    </div>
  </section>
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>
  @import "../../assets/scss/Home/Home";
</style>