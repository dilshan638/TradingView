<template>
    <section class="block-two market-block">
      <div class="container">
          <div class="row">
            <div class="col-md-12">
              <p>Lorem ipsum dolor sit amet, consereerrs</p>
            </div>
          </div>        
          <div class="row">
            <div class="col-lg-2 col-6 col-md-4">
              <div class="block-line">
                <span>LDXI/USD <b>+6.22 %</b></span>
                <h6>1.9323</h6>
                <p>$ 300.32</p>
              </div>
            </div>
            <div class="col-lg-2 col-6  col-md-4">
              <div class="block-line">
                <span>LDXI/USD <b class="minus">+6.22 %</b></span>
                <h6>1.9323</h6>
                <p>$ 300.32</p>
              </div>
            </div>
            <div class="col-lg-2 col-6  col-md-4">
              <div class="block-line">
                <span>LDXI/USD <b>+6.22 %</b></span>
                <h6>1.9323</h6>
                <p>$ 300.32</p>
              </div>
            </div>
            <div class="col-lg-2 col-6  col-md-4">
              <div class="block-line">
                <span>LDXI/USD <b class="minus">+6.22 %</b></span>
                <h6>1.9323</h6>
                <p>$ 300.32</p>
              </div>
            </div>
            <div class="col-lg-2 col-6  col-md-4">
              <div class="block-line">
                <span>LDXI/USD <b>+6.22 %</b></span>
                <h6>1.9323</h6>
                <p>$ 300.32</p>
              </div>
            </div>
            <div class="col-lg-2 col-6  col-md-4">
              <div class="block-line">
                <span>LDXI/USD <b>+6.22 %</b></span>
                <h6>1.9323</h6>
                <p>$ 300.32</p>
              </div>
            </div>            
          </div>
          <div class="row">
            <div class="col-md-12">
              <p class="sm-text">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed</p>
            </div>
          </div>            
      </div>
  </section>
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>
  @import "../../assets/scss/Home/Home";
</style>