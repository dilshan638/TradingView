<template>
        <section class="block-one">
          <div class="container">
              <div class="row">
                  <div class="col-lg-8 left-col order-2">
                      <h5>LDCX, a digital currency exchange<br/>
                      exclusively for members of<br/>
                      INSPIRA Digital Wealth Club</h5>
                      <a href="#" class="block-btn btn">Apply for INSPIRA Membership</a>
                  </div>
                  <div class="col-lg-4 right-col order-1 order-md-2">
                    <h1>INSPIRA</h1>
                    <h4>Digital Wealth Club</h4>
                  </div>
              </div>
          </div>
      </section>  
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>
  @import "../../assets/scss/Home/Home";
</style>