<template>
  <section class="block-three what-section">
    <div class="container">
        <div class="row text-center">
            <div class="col-lg-6">
              <h2>What is INSPIRA</h2>
              <p>INSPIRA is the worlds first Private Digital Wealth club. 
At Inspira we aim to inspire, by investing in future technologies which will advance humanity, whilst also ensuring that these technologies are pro-environment, ecologically friendly and ethical. In the same breath, we also want to engage with our community, so that they benefit directly from these investments and the lifestyle opportunities they bring. 
All our services and investments are managed digitally offering a cost effective, agile wealth management solution.</p>
            </div>
            <div class="col-lg-6 bg-right">
              
            </div>
        </div>
    </div>
  </section>
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>
  @import "../../assets/scss/Home/Home";
</style>