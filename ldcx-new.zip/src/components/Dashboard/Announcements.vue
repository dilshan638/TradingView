<template>
<div class="card">
    <div class="card-header">
        <h2>Announcements</h2>
    </div>
    <div class="card-body no-padding no-padding-all">
        <div class="row">
            <div class="col-md-12">
                <div class="list-group">
                    <a href="#" class="list-group-item list-group-item-action">Sample announcements goes <br>here</a>
                    <a href="#" class="list-group-item list-group-item-action">Sample announcements goes <br>here</a>
                    <a href="#" class="list-group-item list-group-item-action">Sample announcements goes <br>here</a>
                    <a href="#" class="list-group-item list-group-item-action">Sample announcements goes <br>here</a>
                    <a href="#" class="list-group-item list-group-item-action">Sample announcements goes <br>here</a>
                </div>                         
            </div>
        </div>
    </div>                    
</div>  
</template>

<script>
export default {
    components: {
    }

}
</script>

<style>

</style>