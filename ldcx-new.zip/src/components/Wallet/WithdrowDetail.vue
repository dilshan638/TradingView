<template>
   <div>
        <div class="row">
        <div class="col-md-12">
            <div class="card Security-model">
            <div class="card-body Security-model mb-0">
                <div class="row">
                <div class="col-md-3">
                    <p class="Card-ph">Amount</p>
                </div>
                <div class="col-md-9">
                    <p class="Card-ph-2">0.37,434.74 BTC (Network Fee)</p>
                </div>

                <div class="col-md-3">
                    <p class="Card-ph">Address</p>
                </div>
                <div class="col-md-9">
                    <p class="Card-ph-2">34KMALZ4jlMLMmsu5NFg4SZ</p>
                </div>

                <div class="col-md-3">
                    <p class="Card-ph pb-0">Network</p>
                </div>
                <div class="col-md-9">
                    <p class="Card-ph-2 pb-0">BTC - Bitcoin</p>
                </div>
                </div>
            </div>
            </div>
        </div>
    </div>
    <div class="form-group pos-rel sec-row mb-3 mt-3">
        <p class="sub-text">Please enter the  6 Digit code that we have sent a to  +9477***121</p>
        <div class="input-group mb-2">
            <input type="text" class="form-control" placeholder="Mobile verification code">
            <div class="input-group-append">
            <button class="btn btn-outline-secondary" style="margin-top: 0rem; margin-left: 0rem;" type="button">Send</button>
            </div>
        </div>
        <p class="sub-text text-right">Didn't received? <a href="#">Resend</a></p>
    </div>
    <div class="form-group pos-rel sec-row">
        <p class="sub-text">PPlease enter the  6 Digit code that we have sent a to  ab**@**.com</p>
        <div class="input-group mb-2">
            <input type="text" class="form-control" placeholder="Email verification code">
            <div class="input-group-append">
            <button class="btn btn-outline-secondary" style="margin-top: 0rem; margin-left: 0rem;" type="button">Send</button>
            </div>
        </div>
        <p class="sub-text text-right">Didn't received? <a href="#">Resend</a></p>
    </div> 
    <div class="row mt-3">
        <div class="col-md-12 ">
        <p class="Paragraph-Line sub-text">Please enter the 6 Digit code from Google Authenticator</p>             
        <div class="form-group Modal-Textfiel">
            <input type="text" placeholder="Email verification code" class="form-control" />
        </div>
        </div>
    </div>
   </div>
</template>

<script>
export default {

}
</script>


<style lang="scss" scoped>
  @import "Crypto.scss";
</style>