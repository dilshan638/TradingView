<template>
    <VueTradingView />
</template>
<script>

import VueTradingView from 'vue-trading-view';


export default {
    name: 'test',
    components: { VueTradingView },
    data() {
        return {
        }
    }
}

</script>